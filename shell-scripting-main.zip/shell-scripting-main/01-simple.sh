#!/bin/bash

# Comment for my understanding

ls
#cat

## TO execute the script we can execute with
# bash script or sh script

# In Redhat family , BASH and SH are same. IN other OS like Ubuntu those are different.
