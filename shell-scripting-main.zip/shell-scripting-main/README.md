# shell-scripting

List of Topics 

1. She Bang & Comments

2. Print 

3. Variables 

4. Inputs 

5. Functions 

6. Quotes , Redirectors & Exit Status 

7. Conditions 

8. Loops 

Shell script is sequential, Meaning it executes line by lin.
