#!/bin/bash

source components/common.sh
GOLANG dispatch