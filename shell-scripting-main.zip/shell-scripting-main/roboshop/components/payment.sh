#!/bin/bash

source components/common.sh
PYTHON payment