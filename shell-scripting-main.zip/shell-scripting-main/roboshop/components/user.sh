#!/bin/bash

source components/common.sh

NODEJS user