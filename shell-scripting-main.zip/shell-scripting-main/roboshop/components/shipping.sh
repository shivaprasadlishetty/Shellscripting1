#!/bin/bash

source components/common.sh
JAVA shipping