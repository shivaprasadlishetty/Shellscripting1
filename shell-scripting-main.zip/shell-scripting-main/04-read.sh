#!/bin/bash

read -p 'Enter your Name: ' name
read -p 'Enter your Age: ' age

echo "Your Name = ${name}, Your Age = ${age}"
